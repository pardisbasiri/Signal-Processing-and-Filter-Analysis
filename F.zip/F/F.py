import numpy as np
from scipy.io import wavfile
from scipy.io.wavfile import write


def h3(n):
    p = 300
    omega = np.pi / 8
    if n == 300:               # for handling lim 0/0
        return 0.125
    if 2 * p >= n >= 0:
        return (np.sin(omega * (n - p))) / (np.pi * (n - p))
    return 0


def h4(n):
    return 2 * np.cos((np.pi / 4) * n) * h3(n)


def h5(n):
    return 2 * np.cos((np.pi / 2) * n) * h3(n)


samplerate, data = wavfile.read('file_ziba.wav')

h3Resp = np.zeros(data.shape[0])
h4Resp = np.zeros(data.shape[0])
h5Resp = np.zeros(data.shape[0])

for l in range(len(data)):
    h3Resp[l] = h3(l)
    h4Resp[l] = h4(l)
    h5Resp[l] = h5(l)

resH3 = np.convolve(data, h3Resp)
resH4 = np.convolve(data, h4Resp)
resH5 = np.convolve(data, h5Resp)

write("file_ziba_h3.wav", samplerate, resH3)
write("file_ziba_h4.wav", samplerate, resH4)
write("file_ziba_h5.wav", samplerate, resH5)


